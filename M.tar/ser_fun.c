#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include "ser.h"
#include <sqlite3.h>

int send_over(struct sock_sfd *msg);

//管理员账号注册功能
int administrator_enroll(struct sock_sfd *msg)
{
	printf("接收管理员账号注册成功\n");
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	//打开数据库
	sqlite3 *db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	//创建一张储存账号密码的表格
	char sql[128] = "create table if not exists administrator(account char primary key,\
					 password char, n char);";
	//执行sql中的指令
	char *errmsg = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	printf("创建管理员账户密码表格成功\n");

	ssize_t res = 0;
	char account[30] = "";
	char password[30] = "";

	//接收客户端输入的账号
	res = recv(newfd, account, sizeof(account), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	//接收客户端输入的密码
	res = recv(newfd, password, sizeof(password), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	//限定管理员账号只有一位
	bzero(sql, sizeof(sql));
	sprintf(sql, "select * from administrator");
	char **result = NULL;
	int row, column; //行、列
	char *errmsg_2 = NULL;

	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg_2) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
/* 判断是否大于2row */
	if(row >= 1)
	{
	fflush(stdin);
	fflush(stdout);
		bzero(sql, sizeof(sql));
		sprintf(sql, "------管理员账户已存在------\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送[管理员账户已存在]错误成功 {%s}\n", sql);
	fflush(stdin);
	fflush(stdout);
		return -1;
	}


	//插入账号密码与标志位数据
	int n = 0;
	bzero(sql, sizeof(sql));
	sprintf(sql, "insert into administrator values(\"%s\", \"%s\", \"%d\");",\
			account,password,n);
	
	char *errmsg_1 = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg_1) != SQLITE_OK)
	{
	fflush(stdin);
	fflush(stdout);
		//向客户端发送账号已存在
		bzero(sql, sizeof(sql));
		sprintf(sql, "-----该账号已存在-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送错误码[账号已存在]成功\n");
	fflush(stdin);
	fflush(stdout);
		return -1;
	}
	fflush(stdin);
	fflush(stdout);
	
	//发送注册成功
	bzero(sql, sizeof(sql));
	sprintf(sql, "------注册成功------\n");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	fflush(stdin);
	fflush(stdout);

	return 0;
}

/*---------------------------------------------------------*/

//管理员登录
int administrator_login(struct sock_sfd *msg)
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	ssize_t res = 0;
	char account[30] = "";
	char password[30] = "";

	//接收客户端欲登入的账号
	res = recv(newfd, account, sizeof(account), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	//接收客户端欲登入的密码
	res = recv(newfd, password, sizeof(password), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	sqlite3 *db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}
	char sql[256] = "select * from administrator";

	char **result = NULL;
	int row, column; //行、列
	char *errmsg = NULL;

	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "-----该账户不存在，请重新输入------\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送[数据库没有管理员账号]成功\n");
		sqlite3_free_table(result);
		return -1;
	}
	int line = 0, list = 0;
	int i = 3;
	//比较登录的账号密码是否正确
		if(strcmp(result[i], account) == 0)
		{
			printf("管理员登录　, 账号 = %s　密码 = %s 标志位 = %s\n", result[i], result[i+1], result[i+2]);
		}
		else
		{//发送账号输入错误
			printf("管理员账号输入错误　 账号 = %s　密码 = %s 标志位 = %s\n", result[i], result[i+1], result[i+2]);
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "-----账号输入错误-----\n");
			if(send(newfd, sql, sizeof(sql), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}


	//比较密码是否正确
	if(strcmp(result[i+1], password) == 0)
	{
	//判断标志位是否为1，防重复登录
		if(strcmp(result[i+2], "1") == 0)
		{
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "-----重复登录----\n");
			if(send(newfd, sql, sizeof(sql), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}
		//更新accept_flag 更新标志位n
		strcpy(account_flag.account, result[i]);
		flag.n = 1;

		bzero(sql, sizeof(sql));
		sprintf(sql, "-----登录成功-----");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送[%s]成功\n", sql);

		//设置标志位 1
		if(sqlite3_open("666.db", &db) != SQLITE_OK)
		{
			printf("ERROR: %s\n", sqlite3_errmsg(db));
			return -1;
		}
		bzero(sql,sizeof(sql));
		sprintf(sql, "update administrator set n=1  where account=\"%s\";", result[i]);
		char *errmsg_3 = NULL;
		if(sqlite3_exec(db, sql, NULL, NULL, &errmsg_3) != SQLITE_OK)
		{
			printf("ERROR: %s __%d__\n", errmsg, __LINE__);
			return -1;
		}
		return 0;
	}
	else
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "-----密码输入错误-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		sqlite3_free_table(result);
		return -1;
	}

	sqlite3_free_table(result);
	return 0;
}

//添加员工
int add_to_employee(struct sock_sfd *msg)
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	//打开数据库
	sqlite3 *db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	//创建储存员工信息的表格							//primary key
	char sql[400] = "create table if not exists employee_msg(name char, sex char, age char,\
					 address char, wages char, id char primary key, phone char);";
	char *errmsg = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	printf("创建员工表格成功\n");

	char name[30] = "";
	char sex;
	char age[10] = "";
	char address[128] = "";
	char wages[30] = "";
	char id[30] = "";
	char phone[30] = "";

	ssize_t res = recv(newfd, name, sizeof(name), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	res = recv(newfd, &sex, sizeof(sex), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	res = recv(newfd, age, sizeof(age), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	res = recv(newfd, address, sizeof(address), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	res = recv(newfd, wages, sizeof(wages), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	res = recv(newfd, id, sizeof(id), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	res = recv(newfd, phone, sizeof(phone), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}


	bzero(sql, sizeof(sql));
	sprintf(sql, "insert into employee_msg values(\"%s\", \"%c\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\");",\
			name, sex, age, address, wages, id, phone);
	
	char buf[128] = "";
	char *errmsg_1 = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg_1) != SQLITE_OK)
	{
		printf("-----向客户端发送[该工号已存在]成功-----\n");
		bzero(buf, sizeof(buf));
		sprintf(buf, "-----该工号已经存在-----\n");
		if(send(newfd, buf, sizeof(buf), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		return -1;
	}

	bzero(buf, sizeof(buf));
	sprintf(buf, "-----员工信息储存完毕-----\n");
	if(send(newfd, buf, sizeof(buf), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	return 0;
}

//删除员工
int delete_to_employee(struct sock_sfd *msg)
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;
	char buf1[30] = "";
	char buf[128] = "";
	ssize_t res = 0;
	res = recv(newfd, buf1, sizeof(buf1), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	sqlite3 *db = NULL;
	char *errmsg = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	char sql[128] = "select * from employee_msg";
	char **result = NULL;
	int row, column; //行、列
	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	if(row == 0){
		bzero(sql, sizeof(sql));
		sprintf(sql, "\n\t-----员工为空-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送员工信息为空成功\n");
		sqlite3_free_table(result);
		return 0;
	}


	int line = 0, list = 0;
	int i = 7;
	//比较要删除的是否在数据库中
	printf("*****%s %s %s %s %s %s %s*****\n",\
			result[i], result[i+1], result[i+2],\
			result[i+3], result[i+4], result[i+5], result[i+6]\
		  );
	for(line = 0; line < (row*column); line++)
	{
		if(strcmp(result[i], buf1) == 0){
			break;
		}
		else if(line == (row*column-1)){
			bzero(buf, sizeof(buf));
			sprintf(buf, "-----该工号不存在-----\n");
			if(send(newfd, buf, sizeof(buf), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			printf("发送该工号不存在成功\n");
			sqlite3_free_table(result);
			return 0;
			//	goto EXIT;	//跳转结束
		}
		i++;
	}

			bzero(buf, sizeof(buf));
			sprintf(buf, "delete from employee_msg where id=\"%s\";", buf1);
			if(sqlite3_exec(db, buf, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}

			bzero(buf, sizeof(buf));
			sprintf(buf, "-----工号为[%s]的员工已被移除-----\n", buf1);
			if(send(newfd, buf, sizeof(buf), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			//EXIT:
			printf("删除员工完成\n");

			return 0;
}

int flag_zero_employee()	//客户端二级界面退出,员工标志位置0
{
	printf("进入标志位功能\n");
	printf("upd  %s\n", account_flag.account);
	char sql[128] = "";
	sqlite3 *db = NULL;
	char *errmsg = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	sprintf(sql, "update emp_account set n=0  where account=\"%s\";", emp.emp_acc);
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	return 0;
}

int flag_zero_B()	//客户端二级界面退出,管理员标志位置0
{
	printf("进入标志位功能\n");
	printf("upd  %s\n", account_flag.account);
	char sql[128] = "";
	sqlite3 *db = NULL;
	char *errmsg = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	sprintf(sql, "update administrator set n=0  where account=\"%s\";", account_flag.account);
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	return 0;
}

//修改员工信息
int revise_employee(struct sock_sfd *msg)
{
	printf("进入修改员工信息功能\n");
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	char name[30] = "";
	char sex;
	char age[10] = "";
	char address[128] = "";
	char wages[30] = "";
	char id[30] = "";
	char phone[30] = "";

	char buf[128] = "";
	char sql[400] = "";
	char ch;
	ssize_t res = 0;

	//接收要修改员工的ID号
	res = recv(newfd, buf, sizeof(buf), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	strcpy(emp.emp_acc, buf);
	printf("更新id标志位%s\n", emp.emp_acc);

	//打开数据库
	sqlite3 *db = NULL;
	char *errmsg = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}
	char **result = NULL;
	int row, column; //行、列
	char id1[128] = "";

	bzero(sql, sizeof(sql));
	sprintf(sql, "select * from employee_msg");
	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		sprintf(id1, "-----输入错误-----\n");
		if(send(newfd, id1, sizeof(id1), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		return -1;
	}
	if(row == 0){
		bzero(sql, sizeof(sql));
		sprintf(id1, "-----该工号不存在-----\n");
		if(send(newfd, id1, sizeof(id1), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("-----发送[该工号不存在]成功----- %d\n", __LINE__);
		sqlite3_free_table(result);
		return 0;
	}


	int line = 0, list = 0;
	int i = 7;
	//判断ID是否在员工信息列表中
	for(line = 0; line < (row*column); line++)
	{
		if(strcmp(result[i], buf) == 0)
		{
			printf("ID验证正确 result = %s\n", result[i]);
			break;
		}
		else if(line == (row*column-1))
		{
			//发送ID不存在
			printf("-----发送[该工号不存在]成功----- %d\n", __LINE__);
			sprintf(id1, "-----该工号不存在-----\n");
			if(send(newfd, id1, sizeof(id1), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}
		i++;
	}

	//验证成功
	memset(id1, 0, sizeof(id1));
	sprintf(id1, "SUESS");
	if(send(newfd, id1, sizeof(id1), 0) < 0){
		ERR_MSG("send");
		return -1;
	}


	printf("已收到将要修改员工的ID == %s\n", buf);
//	while(1)
//	{
		//接收switch选项
		res = recv(newfd, &ch, sizeof(ch), 0);
		if(res < 0){
			ERR_MSG("recv");
			return -1;
		}else if(0 == res){
			SFD_MSG;
			return -1;
		}

		switch(ch)
		{
		case 'a':
			printf("进入名字修改>>\n");
			res = recv(newfd, name, sizeof(name), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set name=\"%s\" where id=\"%s\";", name, buf);
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			printf("修改完成\n");
			send_over(msg);
			break;

		case 'b':	
			res = recv(newfd, &sex, sizeof(sex), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set sex=\"%c\" where id=\"%s\";", sex, buf);

			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'c':
			printf("进入年龄修改功能\n");
			res = recv(newfd, age, sizeof(age), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}

			printf("将要把年龄修改为%s\n", age);
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set age=\"%s\" where id=\"%s\";", age, buf);
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'e':
			res = recv(newfd, address, sizeof(address), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set address=\"%s\" where id=\"%s\";", address, buf);

			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'f':
			printf("*****进入工资修改功能*****\n");
			res = recv(newfd, wages, sizeof(wages), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			printf("将要把工资修改为%s\n", wages);
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set wages=\"%s\" where id=\"%s\";", wages, buf);

			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'g':	
			bzero(id, sizeof(id));
			res = recv(newfd, buf, sizeof(buf), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set id=\"%s\" where id=\"%s\";", id, buf);

			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'h':	
			bzero(phone, sizeof(phone));
			res = recv(newfd, buf, sizeof(buf), 0);
			if(res < 0){
				ERR_MSG("recv");
				return -1;
			}else if(0 == res){
				SFD_MSG;
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update employee_msg set phone=\"%s\" where id=\"%s\";", phone, buf);

			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			send_over(msg);
			break;

		case 'T':
			return 0;
		}

//			}
	return 0;
}
int send_over(struct sock_sfd *msg){
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	char sql[400] = "";
	bzero(sql, sizeof(sql));
	sprintf(sql, "-----修改完成-----\n");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	return 0;
}

int print_emoloyee(struct sock_sfd *msg)	//查看员工信息
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	sqlite3* db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	char sql[400] = "select * from employee_msg";
	char** result = NULL;                                     
	int row, column;    //行、列
	char *errmsg = NULL;

	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		bzero(sql, sizeof(sql));
		sprintf(sql, "\n\t\t-----员工为空-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送[员工信息为空]成功\n");
		return -1;
	}
	if(row == 0){
		bzero(sql, sizeof(sql));
		sprintf(sql, "\n\t\t-----员工为空-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("发送员工信息为空成功\n");
		sqlite3_free_table(result);
		return 0;
	}


	int i = 0,j = 1, k = 2;
	int line = 0, list = 0; //行、列

	for(line = 0; line < row+1; line++)
	{

		bzero(sql, sizeof(sql));
		sprintf(sql, "%8s%8s%8s%8s%8s%8s%8s\n", \
				result[i], result[i+1], result[i+2], \
				result[i+3], result[i+4], result[i+5], result[i+6]);
		if(send(newfd, sql, sizeof(sql), 0) < 0)
		{
			ERR_MSG("send");
			return -1;
		}
		i+=7;;
	}

	bzero(sql, sizeof(sql));
	sprintf(sql, "OVER");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	return 0;
	sqlite3_free_table(result);
	return 0;
}



int enroll_new_employee(struct sock_sfd *msg)	//注册一位新员工
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	//打开数据库
	sqlite3 *db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	char sql[128] = "create table if not exists emp_account(account char primary key,\
					 password char, n char);";
	char *errmsg = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}

	ssize_t res = 0;
	char account[30] = "";
	char password[30] = "";

	//接收客户端输入的账号
	res = recv(newfd, account, sizeof(account), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}
	//接收客户端输入的密码
	res = recv(newfd, password, sizeof(password), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	//插入账号密码与标志位数据
	int n = 0;
	bzero(sql, sizeof(sql));
	sprintf(sql, "insert into emp_account values(\"%s\", \"%s\", \"%d\");",\
			account,password,n);

	char *errmsg_1 = NULL;
	if(sqlite3_exec(db, sql, NULL, NULL, &errmsg_1) != SQLITE_OK)
	{
		//向客户端发送账号已存在
		char buf[128] = "------账号已存在，请重新输入------\n";
		if(send(newfd, buf, sizeof(buf), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}

	//发送注册成功
	bzero(sql, sizeof(sql));
	sprintf(sql, "-----新员工注册成功-----\n");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	return 0;
}


int enroll_employee_account(struct sock_sfd *msg)	//登录员工个人账号
{	
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	ssize_t res = 0;
	char account[30] = "";
	char password[30] = "";
	char id[30] = "";

	//接收员工登入的账号
	res = recv(newfd, account, sizeof(account), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	//接收员工登入的密码
	res = recv(newfd, password, sizeof(password), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}

	//接收员工的验证ID
	res = recv(newfd, id, sizeof(id), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		SFD_MSG;
		return -1;
	}


	printf("接收到的账号 = %s 密码 = %s id = %s\n", account, password, id);

	sqlite3 *db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}
	char sql[128] = "select * from emp_account";

	char **result = NULL;
	int row, column; //行、列
	char *errmsg = NULL;

	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "-----输入错误-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		return -1;
	}

	int line = 0, list = 0;
	int i = 2;
	//比较登录的账号密码是否正确
	for(line = 0; line < (row*column); line++)
	{
		if(strcmp(result[i], account) == 0)
		{
			printf("账号正确 result = %s\n", result[i]);
			break;
		}
		else if(line == (row*column-1))
		{
			//发送账号输入错误
			printf("发送账号输入错误成功\n");
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "-----账号输入错误-----\n");
			if(send(newfd, sql, sizeof(sql), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}
		i++;
	}
	printf("--%s--%s--%s\n",result[i], result[i+1], result[i+2]);

	//比较密码是否正确
	if(strcmp(result[i+1], password) == 0)
	{
		//判断标志位是否为1，防重复登录
		if(strcmp(result[i+2], "1") == 0)
		{
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "-----重复登录----\n");
			if(send(newfd, sql, sizeof(sql), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}

		//验证ID
		bzero(sql, sizeof(sql));
		sprintf(sql, "select * from employee_msg");

		if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
		{
			printf("ERROR: %s __%d__\n", errmsg, __LINE__);
			return -1;
		}
		if(row == 0){
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "-----该工号不存在-----\n");
			if(send(newfd, sql, sizeof(sql), 0) < 0){
				ERR_MSG("send");
				return -1;
			}
			sqlite3_free_table(result);
			return 0;
		}

		int line = 0, list = 0;
		int i = 7;
		//比较验证的工号是否正确
		for(line = 0; line < (row*column); line++)
		{
			if(strcmp(result[i], id) == 0)
			{
				//更新ID //查看自身信息用 
				ID.id = i;	
				strcpy(emp.emp_acc, account);
				break;
			}
			else if(line == (row*column-1))
			{
				memset(sql, 0, sizeof(sql));
				sprintf(sql, "-----该工号不存在-----\n");
				if(send(newfd, sql, sizeof(sql), 0) < 0){
					ERR_MSG("send");
					return -1;
				}
				sqlite3_free_table(result);
				return 0;
			}
			i++;
		}

		flag.n = 1;

		//设置标志位 1
		if(sqlite3_open("666.db", &db) != SQLITE_OK)
		{
			printf("ERROR: %s\n", sqlite3_errmsg(db));
			return -1;
		}
		bzero(sql,sizeof(sql));
		sprintf(sql, "update emp_account set n=1  where account=\"%s\";", account);
		char *errmsg_3 = NULL;
		if(sqlite3_exec(db, sql, NULL, NULL, &errmsg_3) != SQLITE_OK)
		{
			printf("ERROR: %s __%d__\n", errmsg, __LINE__);
			return -1;
		}

		//发送登录成功信息
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "-----登录成功-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}

		return 0;
	}
	else
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "-----密码输入错误-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		sqlite3_free_table(result);

		return 0;
	}
	return 0;
}

int view_myself_employee_msg(struct sock_sfd *msg) //查看自身的员工信息
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	sqlite3* db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	char sql[400] = "select * from employee_msg";
	char** result = NULL;                                     
	int row, column;    //行、列
	char *errmsg = NULL;

	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}
	if(row == 0)
	{
		bzero(sql, sizeof(sql));
		sprintf(sql, "-----员工列表为空-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		return 0;
	}

	int i = 7;
	int line = 0, list = 0; //行、列

	for(line = 0; line < row; line++)
	{
		if(strcmp(result[i+5], result[ID.id]) == 0)
		{
			bzero(sql, sizeof(sql));
			sprintf(sql, "%8s%8s%8s%8s%8s%8s%8s\n", \
					result[i], result[i+1], result[i+2], \
					result[i+3], result[i+4], result[i+5], result[i+6]);
			if(send(newfd, sql, sizeof(sql), 0) < 0)
			{
				ERR_MSG("send");
				return -1;
			}
			break;
		}
		i+=7;
	}

	bzero(sql, sizeof(sql));
	sprintf(sql, "-----查询完毕-----\n");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	return 0;
	sqlite3_free_table(result);

	return 0;
}

int view_others_employee_msg(struct sock_sfd *msg) //查看别人的基本信息
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;

	sqlite3* db = NULL;
	if(sqlite3_open("666.db", &db) != SQLITE_OK)
	{
		printf("ERROR: %s\n", sqlite3_errmsg(db));
		return -1;
	}

	char sql[400] = "select * from employee_msg";
	char** result = NULL;                                     
	int row, column;    //行、列
	char *errmsg = NULL;


	//三级指针，故&result
	if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
	{
		bzero(sql, sizeof(sql));
		sprintf(sql, "-----员工列表为空-----\n");
		if(send(newfd, sql, sizeof(sql), 0) < 0){
			ERR_MSG("send");
			return -1;
		}
		printf("ERROR: %s __%d__\n", errmsg, __LINE__);
		return -1;
	}

	int i = 7,j = 1, k = 2;
	int line = 0, list = 0; //行、列

	int l = 0;

	char address[30] = "***";
	char wages[30] = "***";
	char id[30] = "***";

	bzero(sql, sizeof(sql));
	sprintf(sql, "%8s%8s%8s%8s%8s%8s%8s\n", \
			result[l], result[l+1], result[l+2], \
			result[l+3], result[l+4], result[l+5], result[l+6]);
	printf("%s", sql);
	if(send(newfd, sql, sizeof(sql), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	for(line = 0; line < row; line++)
	{
		if(strcmp(result[i+5], result[ID.id]) == 0)
		{
			bzero(sql, sizeof(sql));
			sprintf(sql, "%8s%8s%8s%8s%8s%8s%8s\n", \
					result[i], result[i+1], result[i+2], \
					result[i+3], result[i+4], result[i+5], result[i+6]);
			if(send(newfd, sql, sizeof(sql), 0) < 0)
			{
				ERR_MSG("send");
				return -1;
			}
		}
		else
		{
			bzero(sql, sizeof(sql));
			sprintf(sql, "%8s%8s%8s%8s%8s%8s%8s\n", \
					result[i], result[i+1], result[i+2], \
					address, wages, id, result[i+6]);
			if(send(newfd, sql, sizeof(sql), 0) < 0)
			{
				ERR_MSG("send");
				return -1;
			}
		}
		i+=7;;
	}

	bzero(sql, sizeof(sql));
	sprintf(sql, "-----查询完毕-----\n");
	if(send(newfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	sqlite3_free_table(result);

	return 0;
}
/*
//修改员工geren信息
int revise_employee_myself(struct sock_sfd *msg)	//修改自身员工信息
{
printf("进入员工自身修改信息功能\n");
int newfd = msg->newfd;
struct sockaddr_in cin = msg->cin;

char name[30] = "";
char sex;
char age[10] = "";
char address[128] = "";
char wages[30] = "";
char id[30] = "";
char phone[30] = "";

char buf[30] = "";
char sql[400] = "";
char ch;
ssize_t res = 0;

strcpy(buf, emp.emp_acc);
printf("buf = %s    %d\n", buf, __LINE__);
//打开数据库
sqlite3 *db = NULL;
char *errmsg = NULL;
if(sqlite3_open("666.db", &db) != SQLITE_OK)
{
printf("ERROR: %s\n", sqlite3_errmsg(db));
return -1;
}
char **result = NULL;
int row, column; //行、列

bzero(sql, sizeof(sql));
sprintf(sql, "select * from employee_msg");
if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
{
printf("ERROR: %s __%d__\n", errmsg, __LINE__);
return -1;
}

int line = 0, list = 0;
int i = 0;
char id1[128] = "";

printf("已收到将要修改员工的ID == %s\n", buf);
while(1)
{
//接收switch选项
res = recv(newfd, &ch, sizeof(ch), 0);
if(res < 0){
ERR_MSG("recv");
return -1;
}else if(0 == res){
SFD_MSG;
return -1;
}

switch(ch)
{
case 'a':
res = recv(newfd, name, sizeof(name), 0);
if(res < 0){
ERR_MSG("recv");
return -1;
}else if(0 == res){
SFD_MSG;
return -1;
}
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set name=\"%s\" where id=\"%s\";", name, buf);
if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'b':	
res = recv(newfd, &sex, sizeof(sex), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set sex=\"%c\" where id=\"%s\";", sex, buf);

if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'c':
printf("进入年龄修改功能\n");
res = recv(newfd, age, sizeof(age), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}

printf("将要把年龄修改为%s\n", age);
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set age=\"%s\" where id=\"%s\";", age, buf);
if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'e':
res = recv(newfd, address, sizeof(address), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set address=\"%s\" where id=\"%s\";", address, buf);

if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'f':
printf("*****进入工资修改功能*****\n");
res = recv(newfd, wages, sizeof(wages), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}
printf("将要把工资修改为%s\n", wages);
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set wages=\"%s\" where id=\"%s\";", wages, buf);

if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'g':	
bzero(id, sizeof(id));
res = recv(newfd, buf, sizeof(buf), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set id=\"%s\" where id=\"%s\";", id, buf);

if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'h':	
bzero(phone, sizeof(phone));
res = recv(newfd, buf, sizeof(buf), 0);
if(res < 0){
	ERR_MSG("recv");
	return -1;
}else if(0 == res){
	SFD_MSG;
	return -1;
}
bzero(sql, sizeof(sql));
sprintf(sql, "update employee_msg set phone=\"%s\" where id=\"%s\";", phone, buf);

if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
{
	printf("ERROR: %s __%d__\n", errmsg, __LINE__);
	return -1;
}
break;

case 'T':
return 0;
}

bzero(sql, sizeof(sql));
sprintf(sql, "-----修改完成-----\n");
if(send(newfd, sql, sizeof(sql), 0) < 0){
	ERR_MSG("send");
	return -1;
}
}
return 0;
}









*/
