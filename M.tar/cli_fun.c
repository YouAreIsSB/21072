#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "cli.h"
#include <unistd.h>

int administrator_login_success(int sfd);
int add_to_employee(int sfd);	//添加员工
int delete_to_employee(int sfd);	//删除员工
int revise_employee(int sfd);	//修改员工信息
int print_employee(int sfd);	//查看员工信息
int enroll_new_employee(int sfd);	//注册一位新员工

int revise_employee_myself(int sfd);	//修改自身的员工信息
int view_myself_employee_msg(int sfd);	//查看自身的员工信息
int view_others_employee_msg(int sfd);	//查看别人的基本信息


int flag_zero_B(int sfd);	//二级界面退出 管理员标志位置0
int flag_zero_employee(int sfd);	//员工标志位置0


int msg_recv(int sfd); //接收数据

char get_request(int sfd)
{
	printf("\t1.注册管理员账号\n");
	printf("\t2.登录管理员账号\n");
	printf("\t3.登录员工个人账号\n");
	printf("\t4.退出\n");
//	printf("\t5.sqlite3\n");

	return 0;
}

//注册管理员账号
int administrator_enroll(int sfd)
{
	char aenroll = AENROLL;
	if(send(sfd, &aenroll, sizeof(aenroll), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}
	printf("发送注册管理员账号请求成功\n");

	char account[30] = "";
	char password[30] = "";

	printf("请输入要注册的账号:");
	fgets(account, sizeof(account), stdin);
	account[strlen(account)-1] = '\0';
	if(send(sfd, account, sizeof(account), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	printf("请输入要注册的密码:");
	fgets(password, sizeof(password), stdin);
	password[strlen(password)-1] = '\0';
	if(send(sfd, password, sizeof(password), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	ssize_t res = 0;
	char buf[128] = "";
	res = recv(sfd, buf, sizeof(buf), 0);
	printf("%s\n", buf);
	if(res < 0)
	{
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res)
	{
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	return 0;
}

//登录管理员账号
int administrator_login(int sfd)
{
	char buf[256] = "";
	char alogin = ALOGIN;
	if(send(sfd, &alogin, sizeof(alogin), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}
	printf("发送登录请求成功\n");

	char account[30] = "";
	char password[30] = "";

	printf("请输入您的账号>>");
	fgets(account, sizeof(account), stdin);
	account[strlen(account)-1] = '\0';
	if(send(sfd, account, sizeof(account), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}

	printf("请输入您的密码>>");
	fgets(password, sizeof(password), stdin);
	password[strlen(password)-1] = '\0';
	if(send(sfd, password, sizeof(password), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}
	printf("等待接收中...\n");
	ssize_t res = 0;
	res = recv(sfd, buf, sizeof(buf), 0);
	printf("%s\n", buf);
	if(res < 0)
	{
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res)
	{
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	
	if(strcmp(buf, "-----登录成功-----") == 0)
	{
		//	administrator_login_success(sfd);	//二级界面
		return 1;
	}
	return 0;
}

//管理员登录成功
int administrator_login_success(int sfd)
{
	while(1)	
	{
		system("clear");

		printf("1.添加员工\n");
		printf("2.删除员工\n");
		printf("3.修改员工信息\n");
		printf("4.查看员工信息\n");
		printf("5.返回上一级\n");
		printf("6.退出程序\n");
		printf("7.注册一位新员工账号\n");

		char choose;
		printf("请选择>>");
		scanf("%c", &choose);
		while(getchar() != 10);

		switch(choose)
		{
		case '1':
			add_to_employee(sfd);	//添加员工
			break;

		case '2':	
			delete_to_employee(sfd);	//删除员工
			break;

		case '3':
			revise_employee(sfd);	//修改员工信息
			break;

		case '4':
			print_employee(sfd);	//查看员工信息
			break;

		case '5':
			flag_zero_B(sfd);
			return 0;

		case '6':
			exit(1);

		case '7':	//注册一位新员工
			enroll_new_employee(sfd);
			break;

		default:
			printf("\n-----输入错误，请重试-----\n");
		}
		printf("输入任意字符清屏>>");
		while(getchar() != 10);
	}
	return 0;
}

//添加员工
int add_to_employee(int sfd)
{
	char buf[128] = "";
	char ch = ADD;	
	ssize_t res = 0;

	char name[30] = "";
	char sex;
	char age[10] = "";
	char address[128] = "";
	char wages[30] = "";
	char id[30] = "";
	char phone[30] = "";

	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("-----请输入要添加的新员工的信息-----\n");
	printf("新员工的名字:");
	fgets(name, sizeof(name), stdin);
	name[strlen(name)-1] = '\0';
	if(send(sfd, name, sizeof(name), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的性别:");
	scanf("%c", &sex);
	getchar();
	if(send(sfd, &sex, sizeof(sex), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的年龄:");
	fgets(age, sizeof(age), stdin);
	age[strlen(age)-1] = '\0';
	if(send(sfd, age, sizeof(age), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的住址:");
	fgets(address, sizeof(address), stdin);
	address[strlen(address)-1] = '\0';
	if(send(sfd, address, sizeof(address), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的工资:");
	fgets(wages, sizeof(wages), stdin);
	wages[strlen(wages)-1] = '\0';
	if(send(sfd, wages, sizeof(wages), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的工号:");
	fgets(id, sizeof(id), stdin);
	id[strlen(id)-1] = '\0';
	if(send(sfd, id, sizeof(id), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("新员工的电话:");
	fgets(phone, sizeof(phone), stdin);
	phone[strlen(phone)-1] = '\0';
	if(send(sfd, phone, sizeof(phone), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}


	bzero(buf, sizeof(buf));
	res = recv(sfd, buf, sizeof(buf), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	printf("%s\n", buf);

	return 0;
}

//删除员工
int delete_to_employee(int sfd)
{
	char sql[128] = "";
	char ch = DEL;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	printf("请输入要移除的员工工号>>");
	fgets(sql, sizeof(sql), stdin);
	sql[strlen(sql)-1] = '\0';
	if(send(sfd, sql, sizeof(sql), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	bzero(sql, sizeof(sql));
	ssize_t res = recv(sfd, sql, sizeof(sql), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	printf("%s\n", sql);

	return 0;
}

int flag_zero_employee(int sfd)	//员工标志位置0
{
	char ch = FLAG_EMPLOYEE;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}
	return 0;
}
int flag_zero_B(int sfd)	//二级界面退出 标志位置0
{
	char ch = FLAG_B;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}
	return 0;
}


int revise_employee(int sfd)	//修改员工信息
{
	char buf[128] = "";
	ssize_t res = 0;

	char name[30] = "";
	char sex;
	char age[10] = "";
	char address[128] = "";
	char wages[30] = "";
	char id[30] = "";
	char phone[30] = "";
	char choose;

//进入服务器函数
	char ch = REV_MYSELF;	
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
			ERR_MSG("send")	;
			return -1;
		}

	printf("请输入要修改的员工的ID:");
	fgets(buf, sizeof(buf), stdin);
	buf[strlen(buf)-1] = '\0';
	if(send(sfd, buf, sizeof(buf), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}
	//接收工号验证与否
	bzero(buf, sizeof(buf));
	res = recv(sfd, buf, sizeof(buf), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	if(strcmp(buf, "SUESS") != 0){
		printf("%s\n", buf);
		return 0;
	}

	
//	while(1)
//	{
		system("clear");
		printf("1.改修该员工姓名\n");
		printf("2.改修该员工性别\n");
		printf("3.改修该员工年龄\n");
		printf("4.改修该员工住址\n");
		printf("5.改修该员工工资\n");
		printf("6.改修该员工工号\n");
		printf("7.改修该员工电话\n");
		printf("8.返回上一级\n");
		printf("9.退出程序\n");


		printf("请选择>>");
		scanf("%c", &choose);
		while(getchar() != 10);
	
		switch(choose)
		{
		case '1':
			ch = NAME_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新名字:");
			fgets(name, sizeof(name), stdin);
			name[strlen(name)-1] = '\0';
			if(send(sfd, name, sizeof(name), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;
	
		case '2':
			ch = SEX_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的性别:");
			scanf("%c", &sex);
			getchar();
			if(send(sfd, &sex, sizeof(sex), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '3':
			ch = AGE_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的年龄:");
			fgets(age, sizeof(age), stdin);
			age[strlen(age)-1] = '\0';
			if(send(sfd, age, sizeof(age), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '4':
			ch = ADDRESS_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的住址:");
			fgets(address, sizeof(address), stdin);
			address[strlen(address)-1] = '\0';
			if(send(sfd, address, sizeof(address), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '5':
			ch = PHONE_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的工资:");
			fgets(wages, sizeof(wages), stdin);
			wages[strlen(wages)-1] = '\0';
			if(send(sfd, wages, sizeof(wages), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '6':
			ch = 'g';
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的工号:");
			fgets(id, sizeof(id), stdin);
			id[strlen(id)-1] = '\0';
			if(send(sfd, id, sizeof(id), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '7':
			ch = 'h';
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			printf("新的电话:");
			fgets(phone, sizeof(phone), stdin);
			phone[strlen(phone)-1] = '\0';
			if(send(sfd, phone, sizeof(phone), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '8':
			ch = 'T';
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			return 0;

		case '9':
			ch = 'T';
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			exit(1);

		default:
			printf("\n-----输入错误，请重试-----\n");
		}
//		printf("输入任意字符清屏>>");
//		while(getchar() != '\n');
//	}

	return 0;
}


int print_employee(int sfd)	//查看员工信息
{
	char buf[400] =  "";
	char ch = FIN;
	ssize_t res = 0;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	printf("---------------------------------------------------------\n");
	while(1)
	{
		res = recv(sfd, buf, sizeof(buf), 0);
		if(strcmp(buf, "OVER") == 0){
			break;
		}
		if(strcmp(buf, "\n\t\t-----员工为空-----\n") == 0){
			printf("%s\n", buf);
			break;
		}
		printf("%s\n", buf);
		if(res < 0){
			ERR_MSG("recv");
			return -1;
		}
		else if(0 == res){
			exit(1);
		}
	}
	printf("---------------------------------------------------------\n");

	return 0;
}


int enroll_new_employee(int sfd)	//注册一位新员工
{
	char aenroll = NEW;
	if(send(sfd, &aenroll, sizeof(aenroll), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	char account[30] = "";
	char password[30] = "";

	printf("请输入要注册的账号:");
	fgets(account, sizeof(account), stdin);
	account[strlen(account)-1] = '\0';
	if(send(sfd, account, sizeof(account), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	printf("请输入要注册的密码:");
	fgets(password, sizeof(password), stdin);
	password[strlen(password)-1] = '\0';
	if(send(sfd, password, sizeof(password), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}

	ssize_t res = 0;
	char buf[128] = "";
	res = recv(sfd, buf, sizeof(buf), 0);
	printf("%s\n", buf);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	return 0;
}


int employee_login(int sfd)	//登录员工个人账号
{
	char aenroll = BENROLL;
	if(send(sfd, &aenroll, sizeof(aenroll), 0) < 0)
	{
		ERR_MSG("send");
		return -1;
	}
	char account[30] = "";
	char password[30] = "";
	char id[30] = "";

	printf("请输入您的账号>>");
	fgets(account, sizeof(account), stdin);
	account[strlen(account)-1] = '\0';
	if(send(sfd, account, sizeof(account), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}

	printf("请输入您的密码>>");
	fgets(password, sizeof(password), stdin);
	password[strlen(password)-1] = '\0';
	if(send(sfd, password, sizeof(password), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}

	//验证
	printf("[个人信息验证]:请输入你的ID>>");
	fgets(id, sizeof(id), stdin);
	id[strlen(id)-1] = '\0';
	if(send(sfd, id, sizeof(id), 0) < 0)
	{
		ERR_MSG("send")	;
		return -1;
	}
	//更新ID 后面函数用到
	strcpy(ID.id, id);

	ssize_t res = 0;
	char buf[128] = "";
	res = recv(sfd, buf, sizeof(buf), 0);
	printf("%s\n", buf);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}
	else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}

	if(strcmp(buf, "-----登录成功-----\n") == 0)
	{
		fflush(stdin);
		fflush(stdout);
		return 1;
	}

	return 0;
}


int employee_login_success(int sfd)	//进入员工登录成功后界面
{
	while(1)
	{
		system("clear");
		printf("\t1.修改自身的员工信息\n");
		printf("\t2.查看自身的员工信息\n");
		printf("\t3.查看别人的基本信息\n");
		printf("\t4.返回上一级\n");
		printf("\t5.退出程序\n");

		char choose;
		printf("请选择>>");
		scanf("%c", &choose);
		while(getchar() != 10);

		switch(choose)
		{
		case '1':	//修改自身的员工信息
			revise_employee_myself(sfd);
			break;

		case '2':	
			view_myself_employee_msg(sfd);	//查看自身的员工信息
			break;

		case '3':
			view_others_employee_msg(sfd);	//查看别人的基本信息
			break;

		case '4':
			flag_zero_employee(sfd);
			return 0;

		case '5':
			flag_zero_employee(sfd);
			exit(1);

		default:
			printf("\n-----输入错误，请重试-----\n");
		}
		printf("输入任意字符清屏>>");
		while(getchar() != '\n');
	}
	return 0;
}

int revise_employee_myself(int sfd)	//修改自身的员工信息
{
	char buf[128] = "";
	char id[30] = "";
	char ch = REV_MYSELF;	
	ssize_t res = 0;

	//进入服务器函数
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}
	//发送ID
	if(send(sfd, ID.id, sizeof(ID.id), 0) < 0){
		ERR_MSG("send")	;
		return -1;
	}

	//判断验证成功与否
	bzero(buf, sizeof(buf));
	res = recv(sfd, buf, sizeof(buf), 0);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	if(strcmp(buf, "SUESS") != 0){
		printf("%s\n", buf);
		return 0;
	}

	char name[30] = "";
	char sex;
	char age[10] = "";
	char address[128] = "";
	char phone[30] = "";

//	while(1)
//	{
		system("clear");
		printf("\t1.修改我的姓名\n");
		printf("\t2.修改我的性别\n");
		printf("\t3.修改我的年龄\n");
		printf("\t4.修改我的住址\n");
		printf("\t5.修改我的电话号码\n");
		printf("\t6.返回上一级\n");
		printf("\t7.退出程序\n");

		char choose;
		printf("请选择>>");
		scanf("%c", &choose);
		while(getchar() != 10);

		switch(choose)
		{
		case '1':
			ch = NAME_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新名字:");
			fgets(name, sizeof(name), stdin);
			name[strlen(name)-1] = '\0';
			if(send(sfd, name, sizeof(name), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '2':
			ch = SEX_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新性别:");
			scanf("%c", &sex);
			getchar();
			if(send(sfd, &sex, sizeof(sex), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '3':
			ch = AGE_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新年龄:");
			fgets(age, sizeof(age), stdin);
			age[strlen(age)-1] = '\0';
			if(send(sfd, age, sizeof(age), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '4':
			ch = ADDRESS_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新住址:");
			fgets(address, sizeof(address), stdin);
			address[strlen(address)-1] = '\0';
			if(send(sfd, address, sizeof(address), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;;

		case '5':
			ch = PHONE_CHANGE;
			if(send(sfd, &ch, sizeof(ch), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}

			printf("你的新电话:");
			fgets(phone, sizeof(phone), stdin);
			phone[strlen(phone)-1] = '\0';
			if(send(sfd, phone, sizeof(phone), 0) < 0){
				ERR_MSG("send")	;
				return -1;
			}
			msg_recv(sfd);
			break;

		case '6':
			//			flag_zero_B(sfd);
			return 0;

		case '7':
			//			flag_zero_B(sfd);
			exit(1);

		default:
			printf("\n-----输入错误，请重试-----\n");
		}
//		printf("输入任意字符清屏>>");
//		while(getchar() != '\n');
//	}

	return 0;
}
//接收数据
int msg_recv(int sfd)
{
	char buf[128] = "";
	ssize_t res = 0;
	res = recv(sfd, buf, sizeof(buf), 0);
	printf("%s\n", buf);
	if(res < 0){
		ERR_MSG("recv");
		return -1;
	}else if(0 == res){
		fprintf(stderr, "-----服务器关闭-----\n");
		exit(1);
	}
	return 0;
}


int view_myself_employee_msg(int sfd)	//查看自身的员工信息
{
	char buf[400] =  "";
	char ch = FIN_MYSELF;
	ssize_t res = 0;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	while(1)
	{
		res = recv(sfd, buf, sizeof(buf), 0);
		if(strcmp(buf, "-----查询完毕-----\n") == 0){
			break;
		}
		printf("%s\n", buf);
		if(res < 0){
			ERR_MSG("recv");
			return -1;
		}
		else if(0 == res){
			exit(1);
		}
	}
	return 0;
}


int view_others_employee_msg(int sfd)	//查看别人的基本信息
{
	char buf[400] =  "";
	char ch = FIN_OTHERS;
	ssize_t res = 0;
	if(send(sfd, &ch, sizeof(ch), 0) < 0){
		ERR_MSG("send");
		return -1;
	}
	while(1)
	{
		res = recv(sfd, buf, sizeof(buf), 0);
		if(strcmp(buf, "-----查询完毕-----\n") == 0){
			break;
		}
		printf("%s\n", buf);
		if(res < 0){
			ERR_MSG("recv");
			return -1;
		}
		else if(0 == res){
			exit(1);
		}
	}
	return 0;
}













