#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include "ser.h"
#include <sqlite3.h>

#define PORT 8888
#define IP "192.168.1.233"

int do_f(struct sock_sfd *msg);


//回收僵尸进程
void handler(int sig)
{
	while(waitpid(-1, NULL, WNOHANG) > 0);
}

int main(int argc, const char *argv[])
{
	//注册17号信号的处理函数
	__sighandler_t s = signal(17, handler);
	if(SIG_ERR == s)
	{
		ERR_MSG("signal");
		return -1;
	}


	int sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd < 0){
		ERR_MSG("sfd");
		return -1;
	}
	//允许快速重用
	int reuse = 1;
	if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(int)) < 0)
	{
		ERR_MSG("setsocketopt");
		return -1;
	}

	//绑定服务器的IP和端口
	struct sockaddr_in sin;
	sin.sin_family 		= AF_INET;
	sin.sin_port 		= htons(PORT);
	sin.sin_addr.s_addr = inet_addr(IP);

	if(bind(sfd, (struct sockaddr*)&sin, sizeof(sin)) < 0)
	{
		ERR_MSG("bind");
		return -1;
	}

	//监听
	if(listen(sfd, 10) < 0)
	{
		ERR_MSG("listen");
		return -1;
	}

	printf("监听成功\n");

	struct sockaddr_in cin;
	socklen_t addrlen = sizeof(cin);
	struct sock_sfd msg;

	while(1)
	{
		int newfd = accept(sfd, (struct sockaddr*)&cin, &addrlen);
		if(newfd < 0)
		{
			ERR_MSG("accept");
			return -1;
		}
		printf("[%s:%d] newfd=%d 链接成功\n", \
				inet_ntoa(cin.sin_addr), ntohs(cin.sin_port), newfd);
		
		msg.newfd = newfd;
		msg.cin = cin;

		pid_t pid = fork();
		if(pid > 0)
		{
			close(newfd);
		}
		else if(pid == 0)
		{
			close(sfd);
			//
			do_f(&msg);

			close(newfd);
			exit(1);
		}
		else
		{
			ERR_MSG("fork");
			return -1;
		}

	}
	close(sfd);

	return 0;
}

int do_f(struct sock_sfd *msg)
{
	int newfd = msg->newfd;
	struct sockaddr_in cin = msg->cin;
	ssize_t res = 0;
	char choose;
	
	while(1)
	{
		//接收客户端协议
		res = recv(newfd, &choose, sizeof(choose), 0);
		if(res < 0){
			ERR_MSG("recv");
			return -1;
		}
		else if(0 == res)
		{
			SFD_MSG;
			
			printf("更新account标志位 %s %d\n", account_flag.account, flag.n);
			//标志位置0
			sqlite3 *db = NULL;
			if(sqlite3_open("666.db", &db) != SQLITE_OK)
			{
				printf("ERROR: %s\n", sqlite3_errmsg(db));
				return -1;
			}
			char sql[128] = "";
			sprintf(sql, "update administrator set n=0 where account=\"%s\";", account_flag.account);
			char *errmsg = NULL;
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			bzero(sql, sizeof(sql));
			sprintf(sql, "update emp_account set n=0 where account=\"%s\";", emp.emp_acc);
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
			{
				printf("ERROR: %s __%d__\n", errmsg, __LINE__);
				return -1;
			}
			printf("更新yuangong  account标志位 %s %d\n", account_flag.account, flag.n);

			return -1;
		}

		switch(choose)
		{
		case '1':	//管理员账号注册
			administrator_enroll(msg);
			break;

			case '2':	//登录员工个人账号
			enroll_employee_account(msg);
				break;

		case '3':	//管理员登录
			administrator_login(msg);
			break;
		case '5':	//添加员工
			add_to_employee(msg);
			break;

		case '6':
			delete_to_employee(msg);	//删除员工
			break;
		
		case '7':
			revise_employee(msg); 	//修改员工信息
			break;

		case '8':
			print_emoloyee(msg);	//查看员工信息
			break;

		case '9':
			enroll_new_employee(msg);	//注册一位新员工
			break;
	/*	
		case 'H':
			printf("进入自身修改\n");
		    revise_employee_myself(msg);	//修改自身员工信息
			break; 
	*/
		case 'B':
			view_myself_employee_msg(msg); //查看自身的员工信息
			break;

		case 'C':
			view_others_employee_msg(msg); //查看别人的基本信息
			break;

		case 'P':	//客户端二级界面退出，置标志位0
			flag_zero_B();
			break;

		case 'M':
			flag_zero_employee();	//客户端二级界面退出,员工标志位置0
			break;
		}

	}


}


