#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "cli.h"
#include <unistd.h>
#include <signal.h>


#define PORT 8888
#define IP "192.168.1.233"

int main(int argc, const char *argv[])
{
	int sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd < 0)
	{
		ERR_MSG("sfd");
		return -1;
	}

	//允许端口快速重用
	int reuse = 1;
	if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(int)) < 0)
	{
		ERR_MSG("setsockopt");
		return -1;
	}

	struct sockaddr_in sin;
	sin.sin_family      = AF_INET;
	sin.sin_port		= htons(PORT);	//端口号的网络字节序
	sin.sin_addr.s_addr = inet_addr(IP);	//IP地址的网络字节序

	if(connect(sfd, (struct sockaddr*)&sin, sizeof(sin)) < 0)
	{
		ERR_MSG("connect");
		return -1;
	}
	printf("链接成功\n");
	
	int c;
	while(1)
	{
		system("clear");
		get_request(sfd);
		char re;
		printf("请选择>>");
		scanf("%c", &re);
		while(getchar() != 10);
	
		switch(re)
		{
		case '1':	//注册管理员账号
			administrator_enroll(sfd);
			break;

		case '2':
			c = administrator_login(sfd);
			if(c == 1){	//进入管理员登录成功后界面
				administrator_login_success(sfd);
			}
			break;

		case '3':
			c = employee_login(sfd);
			if(c == 1){	//进入员工登录成功后的界面
				employee_login_success(sfd);
			}
			break;

		case '4':
			close(sfd);
			return 0;

/*		case '5':
			system("sqlitebrowser 666.db");
			break;
*/		
		default:
			printf("\n-----输入错误，请重试-----\n");
		}
		printf("输入任意字符清屏>>");
		while(getchar() != '\n');
	}
	close(sfd);

	return 0;
}

