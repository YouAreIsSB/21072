#ifndef __SERVICE__
#define __SERVICE__

/* name
 * 性别
 * 年龄
 * 住址
 * 薪资
 * 工号
 * 电话号码
 */


#define ERR_MSG(msg) do{\
	printf("%s : %s : %d\n", __FILE__,__func__,__LINE__);\
	perror(msg);\
}while(0)

#define SFD_MSG do{\
	fprintf(stderr, "[%s:%d] %d号关闭 __%d__\n", inet_ntoa(cin.sin_addr),\
			ntohs(cin.sin_port), newfd, __LINE__);\
}while(0)

union{
	int n;
}flag;

union{
	char account[30];
}account_flag;
union{
	char emp_acc[30];
}emp;

union{
	char password_flag[30];
}password_flag;

union{
	int id;
}ID;

struct sock_sfd{
	int newfd;
	struct sockaddr_in cin;
};


char reception_request(struct sock_sfd *msg);	//接收客户端协议
int administrator_enroll(struct sock_sfd *msg);	//管理员账号注册
int administrator_login(struct sock_sfd *msg);	//管理员登录
int add_to_employee(struct sock_sfd *msg);	//添加员工
int delete_to_employee(struct sock_sfd *msg);	//删除员工

int revise_employee(struct sock_sfd *msg); 	//修改员工信息
int print_emoloyee(struct sock_sfd *msg);	//查看员工信息
int enroll_new_employee(struct sock_sfd *msg);	//注册一位新员工

int revise_employee_myself(struct sock_sfd *msg);	//修改自身员工信息
int view_myself_employee_msg(struct sock_sfd *msg); //查看他人基本信息
int enroll_employee_account(struct sock_sfd *msg);	//登录员工个人账号
int view_others_employee_msg(struct sock_sfd *msg); //查看别人的基本信息



int flag_zero_B();	//客户端二级界面退出,标志位置0
int flag_zero_employee();	//客户端二级界面退出,员工标志位置0




#endif
