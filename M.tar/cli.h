#ifndef __CLIENT__
#define __CLIENT__


#define AENROLL '1'	 //管理员注册
#define BENROLL '2'	 //登录员工个人账号
#define ALOGIN  '3'	 //管理员登录
#define BLOGIN  '4'	 //员工登录

#define ADD '5'	//增
#define DEL '6'	//删
#define REV '7'	//改
#define FIN '8'	//查

#define NEW '9' //注册新员工

#define REV_MYSELF '7'	//修改自身的员工信息
#define FIN_MYSELF 'B'	//查看自身的员工信息
#define FIN_OTHERS 'C'	//查看别人的基本信息

#define NAME_CHANGE 'a'
#define SEX_CHANGE 'b'
#define AGE_CHANGE 'c'
#define ADDRESS_CHANGE 'e'
#define PHONE_CHANGE 'h'


union{
	char id[30];
}ID;

//#define FLAG_A 'O'
#define FLAG_B 'P'	//标志位置0
#define FLAG_EMPLOYEE 'M'


#define ERR_MSG(msg) do{\
	printf("%s : %s : %d\n", __FILE__,__func__,__LINE__);\
	perror(msg);\
}while(0)


char get_request(int sfd);	//登录注册请求
int administrator_enroll(int sfd);	//注册管理员账号
int administrator_login(int sfd);	//登录管理员账号
int administrator_login_success(int sfd); //管理员登录成功 二级界面
int employee_login(int sfd);	//登录员工个人账号
int employee_login_success(int sfd);	//进入员工登录成功后界面




#endif
